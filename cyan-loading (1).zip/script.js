// CONFIGURATION

var videoId = "mmr6MVhycws"; // The video ID of the YouTube video for the music
var musicVolume = 25; // The volume of the music (0 to 100)

var delayBetweenSlides = 15 * 1000; // 5 seconds in milliseconds
var slides = [
  {
    title: "Mission Objective",
    description:
      "Republic Intelligence has received word of a CIS invasion of the planet Dantooine, a vital location for the Republic and its food supply to the capital city. The Republic has deployed the 5th Fleet to conduct a defensive operation on the planet and safeguard its resources. However, something bigger seems to be at play. Republic Intelligence has dispatched Director Cyan to oversee the garrison stationed on the planet.",
  },
  {
    title: "Welcome recruit",
    description:
      "You have been given orders to transfer to the garrison at Dantooine. Your mission is to help secure the defensive outpost and keep the resources within Republic territory. The 5th Fleet has established a steady blockade on the northern hemisphere of the planet, blocking the hyperspace lane leading to the Inner Rim. Your mission objective: defend the landing zone on the planet.",
  },
];

var pl = document.getElementById("player");

var player;
function onYouTubeIframeAPIReady() {
  player = new YT.Player("player", {
    height: "360",
    width: "640",
    videoId: "mmr6MVhycws",
    events: {
      onReady: onPlayerReady,
    },
    playerVars: {
      controls: 0,
      disablekb: 1,
      enablejsapi: 1,
      fs: 0,
      iv_load_policy: 3,
      loop: 1,
      modestbranding: 1,
      playsinline: 1,
      rel: 0,
      showinfo: 0,
      start: 0,
    },
  });
}

function onPlayerReady(event) {
  event.target.playVideo();
  event.target.setVolume(musicVolume);
}

// ALL THE CODE BELOW IS FOR THE ANIMATION
// DO NOT MODIFY UNLESS YOU KNOW WHAT YOU'RE DOING

var infoTitle = document.getElementById("info-title");
var infoDescription = document.getElementById("info-description");
var animationDuration = 1500;

function animateText(title, description) {
  infoTitle.classList.add("hide");
  infoDescription.classList.add("hide");

  setTimeout(() => {
    infoDescription.classList.remove("revealed");
    infoTitle.classList.remove("revealed");

    infoTitle.innerHTML = title;
    infoDescription.innerHTML = description;

    infoTitle.classList.remove("hide");
    infoDescription.classList.remove("hide");

    setTimeout(() => {
      infoDescription.classList.add("revealed");
      infoTitle.classList.add("revealed");
    }, 5);
  }, animationDuration);
}

var currentSlide = 0;

infoTitle.innerHTML = slides[currentSlide].title;
infoDescription.innerHTML = slides[currentSlide].description;

setInterval(() => {
  currentSlide = (currentSlide + 1) % slides.length;
  animateText(slides[currentSlide].title, slides[currentSlide].description);
}, delayBetweenSlides + animationDuration);
